from Lab3 import *;
sourceIP="200.200.200.200"
destIP="100.100.110.100"
desport=400
srcport=81
choice=3


#choice = 1 sr()
#choice = 2 sr1()
#choice = 3 srloop()
sendPacket(sourceIP,destIP,desport,srcport,choice)
