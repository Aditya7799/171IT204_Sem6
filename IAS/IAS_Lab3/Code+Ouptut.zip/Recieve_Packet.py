from Lab3 import *
ip="100.100.110.100"
print("Sniffing using ip filter: "+ip)
scapy_sniffing("host "+ip)
